package ru.hse.edu.sc.y2020.modul2;

public class ArrayList<T>  implements MyList<T> {
    private static final int DEFAULT_CAPACITY = 10;
    private T[] array = new T[DEFAULT_CAPACITY];
    private int size;
    /**
     * Добавить элемент в список.
     *
     * @param element данные для добавления.
     */
    @Override
    public void add(T element) {
        if (size == array.length){
            T[] tmp = new T[size+1];

        }
    }

    /**
     * Удалить элемент из списка по индексу.
     *
     * @param index индекс элемента для удаления.
     */
    @Override
    public void remove(int index) {

    }

    /**
     * Удалить первый элемент из списка с таким значением.
     *
     * @param element значение элемента для удаления.
     * @return был ли удалён такой элемент.
     */
    @Override
    public boolean remove(T element) {
        return false;
    }

    /**
     * Получить элемент из списка по индексу.
     *
     * @param index индекс элемента.
     * @return элемент по данным индексом в списке.
     */
    @Override
    public T get(int index) {
        return null;
    }

    /**
     * Показать размер списка.
     *
     * @return размер списка.
     */
    @Override
    public int size() {
        return 0;
    }

    /**
     * Проверка на содержание в списке.
     *
     * @param element значение элемента для проверки.
     * @return содержится ли этот элемент в списке.
     */
    @Override
    public boolean contains(T element) {
        return false;
    }
}
