package ru.hse.edu.sc.y2020.seminar03.homework.librari;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 * Класс библиотеки для работы с книгами.
 */
public class Library {
    /**
     * Все книги библиотеки.
     */
    private final ArrayList<Book> books;

    /**
     * Конструктор библиотеки.
     * Выбран именно объектый метод взаимодействия,
     * так как библиотек может быть несколько.
     */
    public Library(){
        books = new ArrayList<Book>();
        random = new Random();
    }

    /**
     * Публичный конструктор библиотеки с параметром массивом.
     * @param arr массив книг для добавления на полки.
     */
    public Library(Book[] arr){
        this();
        books.addAll(Arrays.asList(arr));
    }

    /**
     * Публичный конструктор библиотеки с параметром списком.
     * @param arrList список книг для добавления на полки.
     */
    public Library(ArrayList<Book> arrList){
        this();
        books.addAll(arrList);
    }

    /**
     * Рандомайзер для выбора книги вслепую.
     */
    private final Random random;

    /**
     * Выбор книги вслепую.
     * @return рандомную книгу.
     */
    public Book take(){
        int index = random.nextInt(books.size());
        Book book = books.get(index);
        books.remove(index);
        return book;
    }

    /**
     * Выбор конкретной книги.
     * @param title название книги.
     * @return конкретную книгу.
     */
    public Book take(String title){
        if (isInLibrary(title)){
            for (int i = 0; i < books.size(); i++){
                if (books.get(i).getTittle().equals(title)) {
                    Book book = books.get(i);
                    books.remove(i);
                    return book;
                }
            }
        }

        throw new IllegalArgumentException();
    }

    /**
     * Определить есть ли книга в библиотеке.
     * @param title название книги.
     * @return есть ли книга в библиотеке.
     */
    public boolean isInLibrary(String title){
        for (Book b:
             books) {
            if (b.getTittle().equals(title)) return true;
        }
        return false;
    }
    /**
     * Определить есть ли книга в библиотеке.
     * @param b книга.
     * @return есть ли книга в библиотеке.
     */
    public boolean isInLibrary(Book b){
        return books.contains(b);
    }

    /**
     * Сдать книгу в библиотеку.
     * @param book книга для сдачи.
     */
    public void put(Book book){
        if (book != null) books.add(book);
        else throw new IllegalArgumentException();
    }
}
