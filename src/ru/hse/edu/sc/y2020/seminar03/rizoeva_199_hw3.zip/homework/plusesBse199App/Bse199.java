package ru.hse.edu.sc.y2020.seminar03.homework.plusesBse199App;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

/**
 * Класс группы бпи199.
 */
public class Bse199 {
    /**
     * Список студентов.
     */
    private static final ArrayList<Student> myGroup;

    /**
     * Рандомайзер.
     */
    private static final Random random;

    /**
     * Сейчас спрашиваемый студент.
     */
    private static int currentStudent ;

    /**
     * Мы одни такие, так что объектов не будет.
     */
    private Bse199(){}

    static
    {
        myGroup = new ArrayList<>();
        random = new Random();
        currentStudent = -1;
    }

    /**
     * Выбрать рандомного студента.
     * @return рандомного студента.
     */
    public static Student ChooseRandomStudent(){
        currentStudent = random.nextInt(myGroup.size());
        return myGroup.get(currentStudent);
    }


    /**
     * Вывести рандомного студента.
     * Нас просили именно такой метод. Я сделала.
     */
    public static void SoutRandomStudent(){
        System.out.println(ChooseRandomStudent());
    }

    /**
     * Оценить текущего студента.
     * @param isMarkGood плюсик ставим?
     */
    public static void RateCurrentStudent(boolean isMarkGood){
        if (isMarkGood) myGroup.get(currentStudent).plus();
        else myGroup.get(currentStudent).minus();
    }

    /**
     * Оценить текущего студента плюсиком.
     */
    public static void RateCurrentStudent(){
        RateCurrentStudent(true);
    }

    /**
     * Выбрать студента по фамилии.
     * @param surname фамилия.
     * @return нашелся ли студент.
     */
    public static boolean ChoseCertainStudent(String surname){
        if (IsInGroup(surname)){
            for (Student s:
                 myGroup) {
                if (s.getSurname().equals(surname)){
                    currentStudent = myGroup.indexOf(s);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Выбрать студента по фамилии и имени.
     * @param surname фамилия.
     * @param name имя
     * @return нашелся ли студент.
     */
    public static boolean ChoseCertainStudent(String surname, String name){
        if (IsInGroup(surname, name)){
            for (Student s:
                    myGroup) {
                if (s.getSurname().equals(surname) && s.getName().equals(name)){
                    currentStudent = myGroup.indexOf(s);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Выбрать студента по фио.
     * @param surname фамилия.
     * @param name имя
     * @param fathersname отчество.
     * @return нашелся ли студент.
     */
    public static boolean ChoseCertainStudent(String surname, String name, String fathersname){
        if (IsInGroup(surname, name, fathersname)){
            for (Student s:
                    myGroup) {
                if (s.getSurname().equals(surname) &&
                        s.getName().equals(name) &&
                        s.getFathersName().equals(fathersname)){
                    currentStudent = myGroup.indexOf(s);
                    return true;
                }
            }
        }

        return false;
    }

    /*public static void SoutCertainStudent(String surname){
        if (ChoseCertainStudent(surname)) System.out.println(myGroup.get(currentStudent));
        else System.out.println("Студент не найден.");
    }

    public static void SoutCertainStudent(String surname, String name){
        if (ChoseCertainStudent(surname, name)) System.out.println(myGroup.get(currentStudent));
        else System.out.println("Студент не найден.");
    }

    public static void SoutCertainStudent(String surname, String name, String fathersname){
        if (ChoseCertainStudent(surname, name, fathersname)) System.out.println(myGroup.get(currentStudent));
        else System.out.println("Студент не найден.");
    }
*/

    /**
     * Определить есть ли студент с такой фамилией в группе.
     * @param surname фамилия.
     * @return есть ли студент с такой фамилией.
     */
    public static boolean IsInGroup(String surname){
        for (Student s: myGroup) {
            if (s.getSurname().equals(surname)) return true;
        }

        return false;
    }


    /**
     * Определить есть ли студент с такой фи в группе.
     * @param surname фамилия.
     * @param name имя.
     * @return есть ли студент.
     */
    public static boolean IsInGroup(String surname, String name){
        for (Student s: myGroup) {
            if (s.getSurname().equals(surname) && s.getName().equals(name)) return true;
        }

        return false;
    }

    /**
     * Определить есть ли студент с такой фио в группе.
     * @param surname фамилия.
     * @param name имя.
     * @param fathersname отчество.
     * @return есть ли студент.
     */
    public static boolean IsInGroup(String surname, String name, String fathersname){
        for (Student s: myGroup) {
            if (s.getSurname().equals(surname) &&
                    s.getName().equals(name) &&
                    s.getFathersName().equals(fathersname)) return true;
        }

        return false;
    }

    /**
     * Добавить студента.
     * @param student студент.
     * @return добавился ли.
     */
    public static boolean Add(Student student){
        if (student != null){
            myGroup.add(student);
            currentStudent = myGroup.size()-1;
            return true;
        }

        return false;
    }

    /**
     * Добавить список студентов.
     * @param students список студентов.
     */
    public static void addRange(ArrayList<Student> students){
        students.removeIf(Objects::isNull);
        myGroup.addAll(students);
    }

    /**
     * Удалить студента.
     * @param student студент на отчисление.
     */
    public static void Remove(Student student){
        if (student!= null){
            myGroup.remove(student);
            if (currentStudent >= myGroup.size()) ChooseRandomStudent();
        }
    }

    /**
     * Удачить по фамилии.
     * @param surname фамилия для отчисления.
     */
    public static void Remove(String surname){
        myGroup.removeIf(s -> s.getSurname().equals(surname));
        if (currentStudent >= myGroup.size()) ChooseRandomStudent();
    }

    /**
     * Отчислисть по ФИ.
     * @param surname фамилия.
     * @param name имя.
     */
    public static void Remove(String surname, String name){
        myGroup.removeIf(s -> s.getSurname().equals(surname) && s.getName().equals(name));
        if (currentStudent >= myGroup.size()) ChooseRandomStudent();
    }

    /**
     * Отчислить по ФИО
     * @param surname фамилия.
     * @param name имя.
     * @param fathersname отчестов.
     */
    public static void Remove(String surname, String name, String fathersname){
        myGroup.removeIf(s -> s.getSurname().equals(surname)
                && s.getName().equals(name)
                && s.getFathersName().equals(fathersname));
        if (currentStudent >= myGroup.size()) ChooseRandomStudent();
    }

    /**
     * Вывести всех студентов.
     */
    public  static void showAllStudents(){
        for (Student s:
             myGroup) {
            System.out.println(s);
        }
    }

    /**
     * Показать все оценки за пару.
     */
    public  static void showMarks(){
        for (Student s:
                myGroup) {
            System.out.println(s + ": " + s.getPluses());
        }
    }

    /**
     * Показать текущего отвечающего студжента.
     */
    public static  void showCurrentStudent(){
        System.out.println(myGroup.get(currentStudent));
    }



}
