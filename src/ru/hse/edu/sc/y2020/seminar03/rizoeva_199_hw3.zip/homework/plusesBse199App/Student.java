package ru.hse.edu.sc.y2020.seminar03.homework.plusesBse199App;

import java.util.ArrayList;

/**
 * Класс студента.
 */
public class Student {
    /**
     * Имя студента.
     */
    private final String name;

    /**
     * Фамилия студента.
     */
    private final String surname;

    /**
     * Отчество студента.
     */
    private String fathersName;

    /*private final ArrayList<Integer> marks;*/

    /**
     * Подсчёт плюсиков.
     */
    private int pluses;

    public Student(String surname, String name){
        if (surname.isBlank() ||
                name.isBlank() ||
                (surname.length()<2) ||
                (name.length()<2))
            throw new IllegalArgumentException();
        this.surname = surname.trim();
        this.name = name.trim();
        fathersName = "";
        //marks = new ArrayList<>();
        pluses = 0;
        //marks.add(10);
    }

    public Student(String surname, String name, String fathersName){
        this(surname, name);
        this.fathersName = fathersName.trim();
    }


    /*public void rate(int mark){
        if (mark<0 || mark > 10) throw  new IllegalArgumentException();
        marks.add(mark);
    }
*/

    /**
     * Поставить плюсик.
     */
    public void plus(){
        pluses++;
    }

    /**
     * Поставить минус.
     */
    public void minus(){
        pluses--;
    }

    /**
     * Геттер для имени.
     * @return имя студента.
     */
    public String getName(){
        return name;
    }

    /**
     * Геттер для фамилии.
     * @return фамилию студента.
     */
    public String getSurname(){
        return surname;
    }

    /**
     * Геттер для отчества.
     * @return отчество.
     */
    public String getFathersName(){
        return fathersName;
    }

    /**
     * Геттер плюсиков.
     * @return
     */
    public int getPluses(){
        return pluses;
    }

    /*public ArrayList<Integer> getMarks(){
        return new ArrayList<>(marks);
    }*/

    @Override
    public String toString() {
        return name + " " + surname + " " + fathersName;
    }

    @Override
    public boolean equals(Object obj) {
        return (obj!= null)&&
                (getClass() == obj.getClass())&&
                (name.equals(((Student) obj).name)&&
                        (surname.equals(((Student)obj).surname))&&
                        (fathersName.equals(((Student)obj).fathersName)));
    }
}
